<?php
class db {
 private static $head= "parham";
    
    
    
}