<?php

require '../includes/config.php';

$buy->clearCart();
$generic->refer();