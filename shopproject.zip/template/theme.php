<?php
class theme {
    static public $header="heading";
    static public $footer="footer";
    static public $title="title";
    
}